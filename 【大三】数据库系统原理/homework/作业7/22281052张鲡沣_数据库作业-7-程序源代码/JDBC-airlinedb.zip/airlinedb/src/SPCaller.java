import java.sql.*; // 导入所有java.sql包下的类，包含JDBC核心API

// 存储过程调用器类
public class SPCaller { // 公共类必须与文件名相同 (SPCaller.java)

    // 数据库连接参数
    // Ensure your MySQL server is running and 'airlinedb' database exists
    // Added timezone parameter for newer JDBC versions to avoid warnings/errors
    private static final String DB_URL = "jdbc:mysql://localhost:3306/airlinedb?serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASS = "ww-23451";

    // main 方法：Java 程序的入口点
    // JVM 将从这里开始执行代码
    public static void main(String[] args) {
        System.out.println("程序开始...");
        System.out.println("尝试连接到数据库...");

        // 使用 try-with-resources 块自动管理 Connection 对象，确保连接在使用后关闭
        try (Connection conn = getConnection()) {
            System.out.println("数据库连接成功!");

            // --- 调用查询存储过程 ---
            System.out.println("\n--- 调用 GetFlightsByRoute 存储过程 (查询) ---");
            callGetFlightsByRoute(conn, "PEK", "PVG");
            callGetFlightsByRoute(conn, "ABC", "XYZ");

            // --- 调用数据插入存储过程 ---
            System.out.println("\n--- 调用 AddPassenger 存储过程 (插入) ---");
            String testIdCard = "110101200001019999"; // 示例乘客ID，用于测试
            String testIdCardNew = "110101200001018888"; // 一个新的，用于删除测试的ID

            // 尝试插入一个已存在的乘客 (假设 testIdCard 已存在，会报错)
            System.out.println("尝试插入已存在的乘客 (预期错误):");
            addPassenger(conn, testIdCard, "测试用户-已存在", 25, "13812345678");

            // 插入一个新的乘客，用于后续删除测试
            System.out.println("\n插入一个新的乘客用于删除测试:");
            addPassenger(conn, testIdCardNew, "待删除用户", 30, "13987654321");

            // --- 调用数据修改存储过程 ---
            System.out.println("\n--- 调用 UpdatePassengerPhone 存储过程 (修改) ---");
            // 更新之前已存在的乘客的电话 (假设 testIdCard 对应的乘客存在)
            updatePassengerPhone(conn, testIdCard, "13900000000");
            // 尝试更新不存在的乘客ID，观察输出信息
            updatePassengerPhone(conn, "9999999999999999999", "13012345678");


            // --- 调用数据删除存储过程 ---
            System.out.println("\n--- 调用 DeletePassenger 存储过程 (删除) ---");
            // **重要提示：** 在尝试删除乘客前，请根据您的实际数据情况和数据库中Passenger表上外键（FOREIGN KEY）的设置来决定是否执行删除操作。
            // 如果该乘客在Ticket或Orderinfo表中有关联记录，并且外键没有设置 ON DELETE CASCADE，那么直接删除Passenger记录会因为外键约束而失败，抛出 SQLException。
            // 如果您想成功删除，请确保要删除的Passenger ID没有关联的Ticket和Orderinfo记录，或者在MySQL中修改外键约束为 ON DELETE CASCADE。

            // 我们将尝试删除上面新插入的 testIdCardNew，它应该没有关联记录
            deletePassenger(conn, testIdCardNew);

            // 您也可以尝试删除 testIdCard，如果它有关联记录且没有级联删除，将会报错
            // System.out.println("\n尝试删除可能有关联记录的乘客 (可能会因外键约束失败):");
            // deletePassenger(conn, testIdCard);


        } catch (SQLException e) {
            // 捕获数据库操作过程中可能发生的 SQLException
            System.err.println("数据库操作失败: " + e.getMessage());
            e.printStackTrace(); // 打印详细的堆栈跟踪信息，有助于调试
        } catch (Exception e) {
            // 捕获其他意外的异常
            System.err.println("发生意外错误: " + e.getMessage());
            e.printStackTrace();
        }

        System.out.println("\n程序结束.");
    }

    // 方法：建立与数据库的连接
    // 使用 DriverManager.getConnection 方法
    private static Connection getConnection() throws SQLException {
        // DriverManager 会根据 DB_URL 自动找到并加载合适的JDBC驱动
        // 返回一个 Connection 对象
        return DriverManager.getConnection(DB_URL, USER, PASS);
    }

    // --- 调用特定存储过程的方法 ---
    // 这些方法负责构建 CallableStatement，设置参数，执行存储过程并处理结果

    // 方法：调用 GetFlightsByRoute 存储过程 (查询操作)
    // 使用 CallableStatement 执行 { call GetFlightsByRoute(?, ?) }
    public static void callGetFlightsByRoute(Connection conn, String depAirport, String arrAirport) {
        if (conn == null) return; // 检查连接是否有效

        System.out.println("调用 GetFlightsByRoute for: " + depAirport + " to " + arrAirport);
        String callSQL = "{ call GetFlightsByRoute(?, ?) }"; // JDBC调用语法

        try (CallableStatement cstmt = conn.prepareCall(callSQL)) { // 创建 CallableStatement

            // 设置输入参数 (参数索引从 1 开始对应存储过程定义中的参数顺序)
            cstmt.setString(1, depAirport);
            cstmt.setString(2, arrAirport);

            // 执行存储过程。execute() 返回 true 表示返回了结果集，否则返回 false。
            boolean hasResultSet = cstmt.execute();

            // 处理结果集 (如果存储过程返回一个结果集)
            if (hasResultSet) {
                try (ResultSet rs = cstmt.getResultSet()) { // 获取结果集
                    System.out.println("找到的航班:");
                    // 打印结果集的列头部
                    ResultSetMetaData metaData = rs.getMetaData();
                    int columnCount = metaData.getColumnCount();
                    for (int i = 1; i <= columnCount; i++) {
                        System.out.printf("%-25s", metaData.getColumnLabel(i)); // 使用 getColumnLabel 获取列名或别名
                    }
                    System.out.println();
                    for (int i = 0; i < columnCount; i++) {
                        System.out.print("-------------------------");
                    }
                    System.out.println();

                    while (rs.next()) { // 遍历每一行结果
                        // 按列名检索数据
                        String flightNumber = rs.getString("flight_number");
                        String airModel = rs.getString("air_model");
                        Timestamp depTime = rs.getTimestamp("departure_time");
                        Timestamp arrTime = rs.getTimestamp("arrival_time");
                        String depName = rs.getString("departure_airport_name");
                        String depCity = rs.getString("departure_city");
                        String arrName = rs.getString("arrival_airport_name");
                        String arrCity = rs.getString("arrival_city");
                        String airlineName = rs.getString("airline_name");

                        // 打印检索到的数据
                        System.out.printf("%-25s", flightNumber);
                        System.out.printf("%-25s", airModel);
                        System.out.printf("%-25s", depTime);
                        System.out.printf("%-25s", arrTime);
                        System.out.printf("%-25s", depName);
                        System.out.printf("%-25s", depCity);
                        System.out.printf("%-25s", arrName);
                        System.out.printf("%-25s", arrCity);
                        System.out.printf("%-25s", airlineName);
                        System.out.println(); // 打印完一行数据后换行
                    }
                }
            } else {
                System.out.println("此查询没有返回结果集。");
            }

        } catch (SQLException e) {
            System.err.println("调用 GetFlightsByRoute 存储过程时出错: " + e.getMessage());
            // e.printStackTrace(); // Uncomment for full stack trace
        }
    }

    // 方法：调用 AddPassenger 存储过程 (插入操作)
    // 使用 CallableStatement 执行 { call AddPassenger(?, ?, ?, ?) }
    public static void addPassenger(Connection conn, String idCard, String name, int age, String phone) {
        if (conn == null) return; // 检查连接是否有效

        System.out.println("正在为: " + name + " (" + idCard + ") 调用 AddPassenger 存储过程");
        String callSQL = "{ call AddPassenger(?, ?, ?, ?) }";

        try (CallableStatement cstmt = conn.prepareCall(callSQL)) { // 创建 CallableStatement

            // 设置输入参数
            cstmt.setString(1, idCard);
            cstmt.setString(2, name);
            cstmt.setInt(3, age);
            cstmt.setString(4, phone);

            // 执行存储过程。executeUpdate() 返回受影响的行数。
            int rowsAffected = cstmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("AddPassenger 调用成功。受影响行数: " + rowsAffected);
            } else {
                System.out.println("AddPassenger 存储过程已执行，但没有行受到影响（可能指示插入失败或重复）。");
            }

        } catch (SQLException e) {
            System.err.println("调用 AddPassenger 存储过程时出错: " + e.getMessage());
            // e.printStackTrace(); // 取消注释以获取完整的堆栈跟踪
        }
    }

    // 方法：调用 DeletePassenger 存储过程 (删除操作)
    // 使用 CallableStatement 执行 { call DeletePassenger(?) }
    public static void deletePassenger(Connection conn, String idCard) {
        if (conn == null) return; // 检查连接是否有效

        System.out.println("正在为 ID: " + idCard + " 调用 DeletePassenger 存储过程");
        String callSQL = "{ call DeletePassenger(?) }";

        try (CallableStatement cstmt = conn.prepareCall(callSQL)) { // 创建 CallableStatement

            // 设置输入参数
            cstmt.setString(1, idCard);

            // 执行 DELETE 操作的存储过程
            int rowsAffected = cstmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("DeletePassenger 调用成功。受影响行数: " + rowsAffected);
            } else {
                System.out.println("DeletePassenger 存储过程已执行，但没有行受到影响。乘客 ID '" + idCard + "' 可能不存在或已被删除。");
            }

        } catch (SQLException e) {
            System.err.println("调用 DeletePassenger 存储过程时出错: " + e.getMessage());
            // e.printStackTrace(); // 取消注释以获取完整的堆栈跟踪
        }
    }

    // 方法：调用 UpdatePassengerPhone 存储过程 (修改操作)
    // 使用 CallableStatement 执行 { call UpdatePassengerPhone(?, ?) }
    public static void updatePassengerPhone(Connection conn, String idCard, String newPhone) {
        if (conn == null) return; // 检查连接是否有效

        System.out.println("正在为 ID: " + idCard + " 调用 UpdatePassengerPhone 存储过程，新电话为: " + newPhone);
        String callSQL = "{ call UpdatePassengerPhone(?, ?) }";

        try (CallableStatement cstmt = conn.prepareCall(callSQL)) { // 创建 CallableStatement

            // 设置输入参数
            cstmt.setString(1, idCard);
            cstmt.setString(2, newPhone);

            // 执行 UPDATE 操作的存储过程
            int rowsAffected = cstmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("UpdatePassengerPhone 调用成功。受影响行数: " + rowsAffected);
            } else {
                System.out.println("UpdatePassengerPhone 存储过程已执行，但没有行受到影响。乘客 ID '" + idCard + "' 可能不存在或电话号码已是最新。");
            }

        } catch (SQLException e) {
            System.err.println("调用 UpdatePassengerPhone 存储过程时出错: " + e.getMessage());
            // e.printStackTrace(); // 取消注释以获取完整的堆栈跟踪
        }
    }
}