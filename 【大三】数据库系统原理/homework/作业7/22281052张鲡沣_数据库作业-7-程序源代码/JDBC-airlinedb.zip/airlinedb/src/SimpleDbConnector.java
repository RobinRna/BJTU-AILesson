import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

// 数据库连接器类，用于建立和管理数据库连接，并执行简单查询
public class SimpleDbConnector { // 公共类必须与文件名相同 (SimpleDbConnector.java)

    private Connection conn = null; // 用于存储数据库连接的成员变量

    // 数据库连接参数 (请替换为您的实际信息)
    private static final String DB_URL = "jdbc:mysql://localhost:3306/airlinedb?serverTimezone=UTC"; // 数据库连接URL
    private static final String USER = "root";       // 您的数据库用户名
    private static final String PASS = "ww-23451"; // <<<--- 替换为您的数据库密码！

    // 构造方法：创建 SimpleDbConnector 对象时尝试建立数据库连接
    // 模仿照片中的结构，使用 try-catch 块处理连接异常
    public SimpleDbConnector() {
        try {
            // 尝试通过 DriverManager 获取数据库连接
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            System.out.println("数据库连接建立成功.");
        } catch (SQLException e) {
            // 如果连接失败，捕获 SQLException 并打印错误信息，模仿照片中的结构
            System.err.println("连接数据库时发生错误: " + e.getMessage());
            // 在实际应用中，可能需要更详细的错误处理或日志记录
            // e.printStackTrace(); // 可以取消注释以打印详细堆栈跟踪
        }
    }

    // 方法：获取建立的数据库连接对象
    // 模仿照片中的结构，简单返回内部的 Connection 对象
    // 返回 null 如果连接未成功建立
    public Connection getConnection() {
        return conn;
    }

    // 方法：执行一个简单的SQL查询并打印结果
    // 参数：connection - 已建立的数据库连接；sqlQuery - 要执行的SQL查询语句
    public void executeSimpleQuery(Connection connection, String sqlQuery) {
        // 检查传入的连接是否有效
        if (connection == null) {
            System.err.println("数据库连接无效，无法执行查询。");
            return;
        }

        System.out.println("\n执行简单查询: " + sqlQuery);

        // 使用 try-with-resources 确保 Statement 和 ResultSet 在使用完毕后自动关闭
        try (Statement stmt = connection.createStatement(); // 创建 Statement 对象用于执行 SQL
             ResultSet rs = stmt.executeQuery(sqlQuery)) { // 执行查询并获取结果集

            // 获取结果集的元数据，用于获取列信息 (列名、数量等)
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();

            // 打印查询结果的列头
            System.out.println("查询结果:");
            for (int i = 1; i <= columnCount; i++) {
                // 使用 getColumnLabel(i) 获取列名或别名，通常更稳定
                System.out.printf("%-25s", metaData.getColumnLabel(i));
            }
            System.out.println(); // 换行到下一行

            // 打印一个分隔线以便区分头部和数据
            for (int i = 0; i < columnCount; i++) {
                System.out.print("-------------------------");
            }
            System.out.println();

            // 遍历结果集的每一行
            int rowCount = 0;
            while (rs.next()) { // rs.next() 移动到下一行，如果存在则返回 true
                rowCount++;
                // 遍历当前行的每一列
                for (int i = 1; i <= columnCount; i++) {
                    // 获取当前列的值，并以字符串形式打印
                    // getString(i) 可以获取大多数数据类型的字符串表示
                    System.out.printf("%-25s", rs.getString(i));
                }
                System.out.println(); // 打印完一行数据后换行
            }

            // 如果结果集为空
            if (rowCount == 0) {
                System.out.println("查询未返回任何结果。");
            } else {
                System.out.println("查询完成，共找到 " + rowCount + " 行记录。");
            }


        } catch (SQLException e) {
            // 捕获查询执行过程中可能发生的 SQLException
            System.err.println("执行查询 '" + sqlQuery + "' 时发生错误: " + e.getMessage());
            // e.printStackTrace(); // 可以取消注释以打印详细堆栈跟踪
        }
    }

    // main 方法：程序的入口点
    // JVM 将从这里开始执行代码
    public static void main(String[] args) {
        // 1. 创建 SimpleDbConnector 类的实例，这会在构造方法中尝试建立数据库连接
        SimpleDbConnector dbConnector = new SimpleDbConnector();

        // 2. 获取建立的数据库连接对象
        Connection connection = dbConnector.getConnection();

        // 3. 检查连接是否成功，如果成功则执行简单查询
        if (connection != null) {
            // 定义一个您数据库上的简单 SQL 查询语句
            // 例如，查询 Airport 表中的所有记录
            String simpleSql = "SELECT * FROM Airport";

            // 调用方法执行查询
            dbConnector.executeSimpleQuery(connection, simpleSql);

            // 您可以尝试其他简单的查询来测试，例如：
            // dbConnector.executeSimpleQuery(connection, "SELECT flight_number, air_model FROM Flight LIMIT 5");
            // dbConnector.executeSimpleQuery(connection, "SELECT id_card, passname, age FROM Passenger LIMIT 5");


            // 4. 关闭数据库连接
            // 由于我们在 main 方法中直接使用了 getConnection()，这里需要手动关闭连接。
            // 在更复杂的应用中，推荐使用 try-with-resources 来自动管理连接。
            try {
                if (connection != null && !connection.isClosed()) {
                    connection.close();
                    System.out.println("\n数据库连接已关闭.");
                }
            } catch (SQLException e) {
                System.err.println("关闭数据库连接时发生错误: " + e.getMessage());
            }

        } else {
            System.err.println("未能建立数据库连接，无法执行查询。");
        }
    }
}