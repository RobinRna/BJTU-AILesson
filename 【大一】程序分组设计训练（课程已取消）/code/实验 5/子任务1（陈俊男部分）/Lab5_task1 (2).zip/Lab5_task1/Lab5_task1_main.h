#pragma once
#pragma warning(disable : 4996) 
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#include<io.h>
#include <ctype.h>
int run(int argc, char* argv[]);
